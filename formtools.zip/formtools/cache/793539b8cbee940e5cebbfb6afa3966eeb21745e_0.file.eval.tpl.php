<?php
/* Smarty version 3.1.31, created on 2020-01-22 20:32:32
  from "C:\xampp\htdocs\formtools\global\smarty_plugins\eval.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5e28a35000a583_22651406',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '793539b8cbee940e5cebbfb6afa3966eeb21745e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\formtools\\global\\smarty_plugins\\eval.tpl',
      1 => 1573338105,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e28a35000a583_22651406 (Smarty_Internal_Template $_smarty_tpl) {
$_template = new Smarty_Internal_Template('eval:'.$_smarty_tpl->tpl_vars['eval_str']->value, $_smarty_tpl->smarty, $_smarty_tpl);echo $_template->fetch();
}
}
