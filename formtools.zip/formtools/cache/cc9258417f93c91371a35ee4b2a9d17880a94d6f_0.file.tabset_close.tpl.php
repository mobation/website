<?php
/* Smarty version 3.1.31, created on 2020-01-22 21:05:53
  from "C:\xampp\htdocs\formtools\themes\default\tabset_close.tpl" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.31',
  'unifunc' => 'content_5e28ab21c09a27_20502969',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'cc9258417f93c91371a35ee4b2a9d17880a94d6f' => 
    array (
      0 => 'C:\\xampp\\htdocs\\formtools\\themes\\default\\tabset_close.tpl',
      1 => 1573338107,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5e28ab21c09a27_20502969 (Smarty_Internal_Template $_smarty_tpl) {
?>
  </div><?php }
}
